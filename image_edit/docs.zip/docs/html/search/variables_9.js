var searchData=
[
  ['red_208',['red',['../struct_rgb.html#af4ac69202cc1537dd567ac5d7af8564c',1,'Rgb']]]
];
