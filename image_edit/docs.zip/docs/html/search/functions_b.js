var searchData=
[
  ['pbm_162',['PBM',['../class_p_b_m.html#ac461add1489356763ce0d97b1b9272af',1,'PBM::PBM(std::string in_format, int in_width, int in_height, int color)'],['../class_p_b_m.html#a9cfec85ce523f130cf4348016e65b065',1,'PBM::PBM(std::string in_format, std::ifstream &amp;file)']]],
  ['pgm_163',['PGM',['../class_p_g_m.html#a73b71ef1862c5d3a83665ddf560bb74d',1,'PGM::PGM(std::string in_format, int in_width, int in_height, int color)'],['../class_p_g_m.html#a658800f6449c8a0df99cdc2376222785',1,'PGM::PGM(std::string in_format, std::ifstream &amp;file)']]],
  ['ppm_164',['PPM',['../class_p_p_m.html#a79f3d6f519600b4d4cfb786bb1d5b29e',1,'PPM::PPM(std::string in_format, int in_width, int in_height, Rgb color)'],['../class_p_p_m.html#a3e64ae87d855fc7ae7ddb0e0c4387546',1,'PPM::PPM(std::string in_format, std::ifstream &amp;file)']]]
];
