var searchData=
[
  ['getditheringindex_143',['getDitheringIndex',['../commands_8cpp.html#a50d2d7767ccd25d3e9d7b39a128aed3d',1,'getDitheringIndex():&#160;commands.cpp'],['../commands_8h.html#a50d2d7767ccd25d3e9d7b39a128aed3d',1,'getDitheringIndex():&#160;commands.cpp']]],
  ['getgrayscalebinary_144',['getGrayscaleBinary',['../image_8cpp.html#aafb639ee753e9383309f3cfd2c43c2c5',1,'getGrayscaleBinary(std::ifstream &amp;file):&#160;image.cpp'],['../image_8h.html#aafb639ee753e9383309f3cfd2c43c2c5',1,'getGrayscaleBinary(std::ifstream &amp;file):&#160;image.cpp']]],
  ['getheight_145',['getHeight',['../class_image.html#a78dcb333d968dc3dfc1b0c70f83177ba',1,'Image']]],
  ['getnumberbinary_146',['getNumberBinary',['../image_8cpp.html#adfef4f04ae7f46760c5e864b0f5f9ad5',1,'getNumberBinary(std::ifstream &amp;file):&#160;image.cpp'],['../image_8h.html#adfef4f04ae7f46760c5e864b0f5f9ad5',1,'getNumberBinary(std::ifstream &amp;file):&#160;image.cpp']]],
  ['getpixelgrayscale_147',['getPixelGrayscale',['../class_p_b_m.html#a4fa6f1704ac79460072dd45903369c44',1,'PBM::getPixelGrayscale()'],['../class_p_g_m.html#a7d562a21db810db54b0a120845be660d',1,'PGM::getPixelGrayscale()'],['../class_p_p_m.html#a4137fc627edff7a1ad874b188490898f',1,'PPM::getPixelGrayscale()']]],
  ['getpixelrgb_148',['getPixelRgb',['../class_image.html#a18376edb2f99d51b2b51927ca11b5efa',1,'Image::getPixelRgb()'],['../class_p_b_m.html#a34cc88e5a6a2a49ea1ad6dae337350c9',1,'PBM::getPixelRgb()'],['../class_p_g_m.html#a3546165e4b8738ad0bd18ae0194728be',1,'PGM::getPixelRgb()'],['../class_p_p_m.html#a3cc7c117dd454dca5e83f7a5e094531d',1,'PPM::getPixelRgb()']]],
  ['getrgbbinary_149',['getRgbBinary',['../image_8cpp.html#a10128ad2c4ae7c6f219ffd0a06149822',1,'getRgbBinary(std::ifstream &amp;file):&#160;image.cpp'],['../image_8h.html#a10128ad2c4ae7c6f219ffd0a06149822',1,'getRgbBinary(std::ifstream &amp;file):&#160;image.cpp']]],
  ['getsaveformat_150',['getSaveFormat',['../image_8cpp.html#a5abbbac302f330ea93b9faaa5c301b15',1,'getSaveFormat():&#160;image.cpp'],['../image_8h.html#a5abbbac302f330ea93b9faaa5c301b15',1,'getSaveFormat():&#160;image.cpp']]],
  ['getwidth_151',['getWidth',['../class_image.html#a813bd3d8d9157c68ed32d3d36d9d01ca',1,'Image']]],
  ['grayscaletorgb_152',['grayscaleToRgb',['../image_8cpp.html#a5a81ef6c5befa5f83ed56139f4b319c8',1,'grayscaleToRgb(int value, int max_value):&#160;image.cpp'],['../image_8h.html#a5a81ef6c5befa5f83ed56139f4b319c8',1,'grayscaleToRgb(int value, int max_value):&#160;image.cpp']]]
];
