var searchData=
[
  ['save_78',['save',['../class_commands.html#a84cba8e5c8910d72b5d4eaf93a986c78',1,'Commands']]],
  ['saveas_79',['saveas',['../class_commands.html#a4aa3d76a709d84637b1977e00b083642',1,'Commands']]],
  ['setpixel_80',['setPixel',['../class_image.html#a83b8a9a59862b53a78dcd9d78ae69b0d',1,'Image::setPixel()'],['../class_p_b_m.html#a685901fbb7477233822fdbf0d7762ef0',1,'PBM::setPixel()'],['../class_p_g_m.html#a6e124793a6645b078a05686a037924f3',1,'PGM::setPixel()'],['../class_p_p_m.html#a445eaec916e81d1ce837b5f9eec63065',1,'PPM::setPixel()']]],
  ['sierradithering_81',['sierraDithering',['../class_image_editor.html#ab0eef5bfeb824dd8543284143fa970ef',1,'ImageEditor']]],
  ['sierralite_82',['sierraLite',['../class_image_editor.html#a4b5df7e12e7a2d7e24e1e92399fc1a9a',1,'ImageEditor']]],
  ['startdimensionediting_83',['startDimensionEditing',['../class_image.html#a56c8a29f4e1af115c7667481675a16fa',1,'Image::startDimensionEditing()'],['../class_p_b_m.html#a7b62294a5273a7268ecd0791f4f3f237',1,'PBM::startDimensionEditing()'],['../class_p_g_m.html#ada8d520101da2bd2567371f7681698bc',1,'PGM::startDimensionEditing()'],['../class_p_p_m.html#abe8c2a75dde612d6e14723bd943004ad',1,'PPM::startDimensionEditing()']]],
  ['stuckidithering_84',['stuckiDithering',['../class_image_editor.html#a9e0c093c0eea59e072353a9c05d8dde3',1,'ImageEditor']]]
];
