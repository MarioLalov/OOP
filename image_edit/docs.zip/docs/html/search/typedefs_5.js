var searchData=
[
  ['iconfigptr_1626',['IConfigPtr',['../namespace_catch.html#afd20a5d4f9d2f4d525db81a7765367b0',1,'Catch']]],
  ['ireporterfactoryptr_1627',['IReporterFactoryPtr',['../namespace_catch.html#ad1b36ac40c2739e52fd453dcdddf0d09',1,'Catch']]]
];
