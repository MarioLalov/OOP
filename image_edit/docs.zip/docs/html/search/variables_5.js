var searchData=
[
  ['green_203',['green',['../struct_rgb.html#a8c6f263db117f731cd7d15b45dbca855',1,'Rgb']]]
];
