var searchData=
[
  ['burkesdithering_128',['burkesDithering',['../class_image_editor.html#a909312cf5f3f49b1638ff542f2b949ce',1,'ImageEditor']]]
];
