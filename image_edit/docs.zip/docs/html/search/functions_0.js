var searchData=
[
  ['allocatenew_124',['allocateNew',['../class_p_b_m.html#ae0a8d28e6b5f4533ba3c80214c198a8f',1,'PBM::allocateNew()'],['../class_p_g_m.html#a40d555863ca350682d4c4e24885047b5',1,'PGM::allocateNew()'],['../class_p_p_m.html#a6252c49b494eb3b33630ef1ed5e57760',1,'PPM::allocateNew()']]],
  ['assignintvalues_125',['assignIntValues',['../image__editor_8cpp.html#a4702f90e39ee512ea40cde58208d93d5',1,'assignIntValues(int &amp;value, int &amp;destValue, int &amp;errorValue):&#160;image_editor.cpp'],['../image__editor_8h.html#a4702f90e39ee512ea40cde58208d93d5',1,'assignIntValues(int &amp;value, int &amp;destValue, int &amp;errorValue):&#160;image_editor.cpp']]],
  ['assignnewvalues_126',['assignNewValues',['../image__editor_8cpp.html#ab303596096922ecfa288823392f70f60',1,'assignNewValues(Rgb value, Rgb &amp;destValue, Rgb &amp;errorValue):&#160;image_editor.cpp'],['../image__editor_8h.html#ab303596096922ecfa288823392f70f60',1,'assignNewValues(Rgb value, Rgb &amp;destValue, Rgb &amp;errorValue):&#160;image_editor.cpp']]],
  ['atkinsondithering_127',['atkinsonDithering',['../class_image_editor.html#a343d0c181981e6024bcd1c5a6b37e1d6',1,'ImageEditor']]]
];
