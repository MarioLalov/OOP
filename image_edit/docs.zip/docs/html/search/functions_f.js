var searchData=
[
  ['validateformat_182',['validateFormat',['../class_image.html#ac5848cc4c3a7c72d176617013739e5f8',1,'Image::validateFormat()'],['../class_p_b_m.html#a0972ba81b7e7b0ffd2efee7c8907ac13',1,'PBM::validateFormat()'],['../class_p_g_m.html#aaea28f59b7bde1179b1357f1d69f1a20',1,'PGM::validateFormat()'],['../class_p_p_m.html#aac26eb7d98f58309f0ed4328b8dffb8a',1,'PPM::validateFormat()']]]
];
