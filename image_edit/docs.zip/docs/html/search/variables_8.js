var searchData=
[
  ['picture_207',['picture',['../class_p_b_m.html#a189cc5b82e9dc30de328911994f98e17',1,'PBM::picture()'],['../class_p_g_m.html#a594961c23013abee79cad1d21aa4d0b8',1,'PGM::picture()'],['../class_p_p_m.html#a1ed679ab4b8dc0170ad3864d2827309d',1,'PPM::picture()']]]
];
