var searchData=
[
  ['editingheight_199',['editingHeight',['../class_image.html#a8bfa7ddc7aca4e544682da2ae1204353',1,'Image']]],
  ['editingpicture_200',['editingPicture',['../class_p_b_m.html#a761d1dc4f1364b391fd6f9ac6779119a',1,'PBM::editingPicture()'],['../class_p_g_m.html#a7054ad599ec830a9872feda6516a6a1e',1,'PGM::editingPicture()'],['../class_p_p_m.html#a7b0e449b7c45d6d777fa602f41eedeff',1,'PPM::editingPicture()']]],
  ['editingwidth_201',['editingWidth',['../class_image.html#af5c5f6d25a832d30c559607f58c3aa16',1,'Image']]]
];
