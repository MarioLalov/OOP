var searchData=
[
  ['flippixel_28',['flipPixel',['../class_p_b_m.html#a7c15d46c0f2ed9a6ccead483045d595f',1,'PBM']]],
  ['floyddithering_29',['floydDithering',['../class_image_editor.html#a67a56d62f322b10e65b9f78235c90268',1,'ImageEditor']]],
  ['format_30',['format',['../class_image.html#a9808a8b4b6d9b563f01c87b5946475d2',1,'Image']]]
];
