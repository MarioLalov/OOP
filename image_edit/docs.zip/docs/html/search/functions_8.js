var searchData=
[
  ['jarvisdithering_154',['jarvisDithering',['../class_image_editor.html#a982d6958a06d1ac02016b4583db1d604',1,'ImageEditor']]]
];
