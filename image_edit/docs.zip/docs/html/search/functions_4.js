var searchData=
[
  ['enddimensionediting_138',['endDimensionEditing',['../class_image.html#a6a2f1f9f881791fd55dfcc11b2417f0a',1,'Image::endDimensionEditing()'],['../class_p_b_m.html#abf72f6bcc0ad12b1fb633cb1da9f56d7',1,'PBM::endDimensionEditing()'],['../class_p_g_m.html#add9f31d6a5d464a69a9d68f60471db7e',1,'PGM::endDimensionEditing()'],['../class_p_p_m.html#a1a0538bcc392170157f62144adab16ec',1,'PPM::endDimensionEditing()']]],
  ['errordiffusion_139',['errorDiffusion',['../class_image_editor.html#aa44a002f6dd75246441e1c99561ed88d',1,'ImageEditor']]],
  ['exit_140',['exit',['../class_commands.html#a0227c5d7627d0e29983d387e594b28ad',1,'Commands']]]
];
