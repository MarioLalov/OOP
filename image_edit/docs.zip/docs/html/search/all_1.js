var searchData=
[
  ['blue_4',['blue',['../struct_rgb.html#aea6ccb8fa3395054f55165c718572c93',1,'Rgb']]],
  ['burkesdithering_5',['burkesDithering',['../class_image_editor.html#a909312cf5f3f49b1638ff542f2b949ce',1,'ImageEditor']]]
];
