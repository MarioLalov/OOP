var searchData=
[
  ['readbinary_165',['readBinary',['../class_p_b_m.html#acac8a2af5be68c33ab392329906b5896',1,'PBM::readBinary()'],['../class_p_g_m.html#aa0b95e36d612c98d75865c91ea339a49',1,'PGM::readBinary()'],['../class_p_p_m.html#a79bf3075de8d25a0e63b7a72ed597059',1,'PPM::readBinary()']]],
  ['readtext_166',['readText',['../class_p_b_m.html#aed467a37bb85d13531c9094680544b37',1,'PBM::readText()'],['../class_p_g_m.html#ae80099e6c208d9902b24d45b8f589710',1,'PGM::readText()'],['../class_p_p_m.html#a13a520c1df92209f9e8ade9f0a869c49',1,'PPM::readText()']]],
  ['resize_167',['resize',['../class_commands.html#adf6fa6947ffb167c3050ad23ebccdedb',1,'Commands::resize()'],['../class_image_editor.html#ab15f6b2ad40fe5067631e5da81be1189',1,'ImageEditor::resize()']]],
  ['rgb_168',['Rgb',['../struct_rgb.html#ad02e1727b35072d46c4d4541ead811cb',1,'Rgb::Rgb()'],['../struct_rgb.html#ad77bb4e17f4c52e0126e3db402df045f',1,'Rgb::Rgb(int in_red, int in_green, int in_blue)']]],
  ['rgbtograyscale_169',['RgbToGrayscale',['../image_8cpp.html#ac51b305e77e9ae8d77de862693aec14a',1,'RgbToGrayscale(Rgb Rgb_value, int max_value):&#160;image.cpp'],['../image_8h.html#ab378b979205d627003dd463dc7ae8461',1,'RgbToGrayscale(Rgb, int max_value):&#160;image.cpp']]],
  ['roundtoint_170',['roundToInt',['../image_8cpp.html#abf37077834b094de44fb8eab16784d1a',1,'roundToInt(double num):&#160;image.cpp'],['../image_8h.html#abf37077834b094de44fb8eab16784d1a',1,'roundToInt(double num):&#160;image.cpp']]]
];
