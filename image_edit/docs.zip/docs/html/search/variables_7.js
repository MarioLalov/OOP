var searchData=
[
  ['maxgrayscalevalue_205',['maxGrayscaleValue',['../class_p_g_m.html#a868ce3b911e8e50a761b2c9f1ab3d2e4',1,'PGM']]],
  ['maxrgbvalue_206',['maxRgbValue',['../class_p_p_m.html#a0a3b73f79fbf14c58c389dc0c55b0a6e',1,'PPM']]]
];
