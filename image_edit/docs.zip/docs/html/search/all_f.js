var searchData=
[
  ['thresholdmap_85',['thresholdMap',['../image__editor_8cpp.html#a092b27a2b4ce74d854368501f138290b',1,'thresholdMap(std::size_t i, std::size_t j, int n):&#160;image_editor.cpp'],['../image__editor_8h.html#a092b27a2b4ce74d854368501f138290b',1,'thresholdMap(std::size_t i, std::size_t j, int n):&#160;image_editor.cpp']]],
  ['toupper_86',['toUpper',['../commands_8cpp.html#ab20b80b5d05da257de700e8c54f0cb6a',1,'toUpper(std::string &amp;input):&#160;commands.cpp'],['../commands_8h.html#ab20b80b5d05da257de700e8c54f0cb6a',1,'toUpper(std::string &amp;input):&#160;commands.cpp']]],
  ['twodimerrordiffusion_87',['twoDimErrorDiffusion',['../class_image_editor.html#afcedca1113797bbb6ce5a23a9dbf3d0a',1,'ImageEditor']]],
  ['tworowsierra_88',['twoRowSierra',['../class_image_editor.html#a10f4e1312b900d9dcbc88effe92165ad',1,'ImageEditor']]]
];
