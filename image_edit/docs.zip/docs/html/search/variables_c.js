var searchData=
[
  ['red_1604',['red',['../struct_rgb.html#af4ac69202cc1537dd567ac5d7af8564c',1,'Rgb']]],
  ['resultdisposition_1605',['resultDisposition',['../struct_catch_1_1_assertion_info.html#a60353b3632ab2f827162f2b2d6911073',1,'Catch::AssertionInfo']]]
];
