var searchData=
[
  ['format_202',['format',['../class_image.html#a9808a8b4b6d9b563f01c87b5946475d2',1,'Image']]]
];
