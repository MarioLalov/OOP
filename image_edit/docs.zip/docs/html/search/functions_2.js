var searchData=
[
  ['checkforcomments_129',['checkForComments',['../image_8cpp.html#ac8d17038cc77820404213865a846877e',1,'checkForComments(std::ifstream &amp;file):&#160;image.cpp'],['../image_8h.html#ac8d17038cc77820404213865a846877e',1,'checkForComments(std::ifstream &amp;file):&#160;image.cpp']]],
  ['checkforcommentsbinary_130',['checkForCommentsBinary',['../image_8cpp.html#a3701bbe7e610faf03115cccd19303287',1,'checkForCommentsBinary(std::ifstream &amp;file):&#160;image.cpp'],['../image_8h.html#a3701bbe7e610faf03115cccd19303287',1,'checkForCommentsBinary(std::ifstream &amp;file):&#160;image.cpp']]],
  ['converttoascii_131',['convertToASCII',['../image_8cpp.html#a1dfcf03d811d8ea77e02496fa4c3ed98',1,'convertToASCII(int num):&#160;image.cpp'],['../image_8h.html#a1dfcf03d811d8ea77e02496fa4c3ed98',1,'convertToASCII(int num):&#160;image.cpp']]],
  ['copytoediting_132',['copyToEditing',['../class_image.html#a1872784baff111b5bf2e84fb2954b5c4',1,'Image::copyToEditing()'],['../class_p_b_m.html#ae2e72ca81f39f394af69c3ce22b071a6',1,'PBM::copyToEditing()'],['../class_p_g_m.html#ae14c2ddca77e110d94a258ee082697b4',1,'PGM::copyToEditing()'],['../class_p_p_m.html#a8683225c6c54f5cd1e405b4bead2097f',1,'PPM::copyToEditing()']]],
  ['createnew_133',['createNew',['../class_commands.html#a9d3a584ce74a494a9bab37552d78cee4',1,'Commands']]],
  ['crop_134',['crop',['../class_commands.html#aa4819bdd0dd7d6da03e991a48110fb90',1,'Commands::crop()'],['../class_image_editor.html#a1f022819e6b18fc9287ee3fbd1e44814',1,'ImageEditor::crop()']]]
];
